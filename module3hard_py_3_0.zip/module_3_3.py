# Домашнее задание по уроку "Распаковка позиционных параметров".
# Назаров ПВ

def print_params(a = 1, b = 'строка', c = True):
  print(print_params)


print_params()